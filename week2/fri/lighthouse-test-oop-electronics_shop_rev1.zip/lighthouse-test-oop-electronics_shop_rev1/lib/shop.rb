class Shop

  attr_reader :name, :inventory, :sales

  def initialize(name)
    @name = name
    @inventory = []
    @sales = []
  end

  def add_to_inventory(item)
    @inventory << item
  end

  def sell_item(item)
    if !@inventory.include?(item)
      false
    else
      @sales.push(item)
    end
    @inventory.delete(item)
    item
  end
end