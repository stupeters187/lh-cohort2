class Cellphone < Product

  def intialize(name, price)
    super(name, price)
  end

end